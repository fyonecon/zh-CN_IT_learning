from django.apps import AppConfig


class MysqlConfig(AppConfig):
    name = 'mysql'
