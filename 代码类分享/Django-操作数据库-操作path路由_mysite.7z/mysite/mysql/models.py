from django.db import models

# Create your models here.


class User(models.Model):
    """用户"""
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=40)
    email = models.EmailField()

    def __unicode__(self):
        return u'%s %s' % (self.first_name, self.last_name)

    pass


class Music(models.Model):
    music_name = models.CharField(max_length=200)
    music_src = models.CharField(max_length=200)
    create_time = models.ImageField(max_length=200)
    adm = models.CharField(max_length=200)
    pass
