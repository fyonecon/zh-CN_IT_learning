from django.contrib import admin

# Register your models here.

# from django.db import models
#
# admin.site.register(models.td_blesslist)
