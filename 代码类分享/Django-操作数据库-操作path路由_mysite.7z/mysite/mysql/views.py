from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse
from django.db import models

# python manage.py runserver 8080


def index(request):
    return HttpResponse("空目录。mysql-index目录")


def data(request):

    the_find = models.Music.object.get(id=18)

    return HttpResponse(the_find)
    pass
