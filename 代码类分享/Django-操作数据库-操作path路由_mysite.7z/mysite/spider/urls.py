from django.urls import path

from . import views, weibos, xiaoshuos

urlpatterns = [
    path('', views.index, name='index'),
    path('index/', views.index, name='index'),

    path('test/id/<_id>', views.weibo, name='weibo'),
    path('weibo/id/<_id>', weibos.weibo, name='weibo'),
    # path('xiaoshuo/id/<_id>', xiaoshuos.xiaoshuo, name='xiaoshuo'),

]
