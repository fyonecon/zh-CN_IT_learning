from django.urls import path

from . import data

urlpatterns = [
    path('', data.index, name='index'),

    path('show/', data.show, name='show'),
    path('add/', data.add, name='add'),
    path('update/', data.update, name='update'),

]
