from django.http import HttpResponse
from .models import Music
import json


# python manage.py runserver 8080
def index(request):
    return HttpResponse('路由运行正常')
    pass


def show(request):  # 查询数据
    res = Music.objects.all().order_by('-id').values('music_name', 'adm')
    if res:
        back = {
            'state': 1,
            'msg': '获取成功',
            'content': list(res),  # 将查询结果数组化
        }
        pass
    else:
        back = {
            'state': 0,
            'msg': '获取失败',
            'content': '',
        }
        pass

    return HttpResponse(json.dumps(back, ensure_ascii=False), content_type='application/json; charset=utf-8')
    pass


def add(request):  # 新增数据

    res = Music(music_name='name3', music_src='www.1111.com/1.mp3', adm='admin1', create_time='2018').save()

    back = {
        'state': 1,
        'msg': '添加成功',
        'content': str(res),
    }

    return HttpResponse(json.dumps(back, ensure_ascii=False), content_type='application/json; charset=utf-8')
    pass


def update(request):  # 更新数据

    res = Music.objects.filter(id=20).update(music_name='name20', adm='admin21')

    if res == 1:
        back = {
            'state': 1,
            'msg': '更新完成',
            'content': str(res),
        }
        pass
    else:
        back = {
            'state': 0,
            'msg': '更新失败',
            'content': str(res),
        }
        pass

    return HttpResponse(json.dumps(back, ensure_ascii=False), content_type='application/json; charset=utf-8')
    pass
