from django.db import models
# Create your models here.


class Music(models.Model):  # 连接数据库中的表，并声明数据库字段

    # 声明参数，可以与数据库的最大长度不同，建议将数据库中所有字段都声明
    id = models.IntegerField(primary_key=True)
    music_name = models.TextField(max_length=100)
    music_src = models.CharField(max_length=500)
    adm = models.CharField(max_length=20)
    create_time = models.IntegerField(max_length=20)

    class Meta:
        managed = True  # 管理每个表的创建，修改和删除
        db_table = 'td_music'  # 表

        pass

    pass
