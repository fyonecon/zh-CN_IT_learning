from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse
import json


def index(requst):
    message = '空目录。Django服务已经启动。'

    return HttpResponse(message)


def test(request):
    print(request)

    return HttpResponse('route is success')


def data1(request):  # GET传参
    if 'p1' in request.GET or 'p2' in request.GET:
        message = '内容为: p1=' + str(request.GET.get('p1')) + '== p2=' + str(request.GET.get('p2'))
    else:
        message = '空get'
    return HttpResponse(message)


def data2(request, p1, p2):  # pathinfo传参
    message = 'p1=' + str(p1) + '== p2=' + str(p2)

    return HttpResponse(message)


def json1(request, p1, p2):
    message = {
        'p1': p1,
        'p2': p2,
    }
    return HttpResponse(json.dumps(message, ensure_ascii=False), content_type='application/json; charset=utf-8')

