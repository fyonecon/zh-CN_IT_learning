import threading
import time


class my_thread(threading.Thread):
    def __init__(self, th_id, th_name):
        threading.Thread.__init__(self)
        self.th_id = th_id
        self.th_name = th_name
        pass

    def run(self):
        print("开始线程：" + self.th_name)
        run_func(self.th_name)
        print("退出线程：" + self.th_name)

    pass


exitFlag = 0


def run_func(th_name):
    if exitFlag:
        th_name.exit()
        pass
    else:
        # print('运行线程：' + th_name)
        do(th_name)
        pass
    print('---%s---' % (time.ctime(time.time())))
    # time.sleep(0.1)
    pass


# 自定义，在此定义你要运行的参数
def do(th_name):
    print('---执行自定义函数---')

    pass


def index(sync):
    print('开始创建线程。。')
    for create in range(0, 2000):
        # 创建新线程
        th = my_thread(create, "Thread-" + str(create))  # id, name
        th.start()
        if sync:  # 线程同步异步开关，True/False
            th.join()
            pass
        else:  # 异步，推荐
            pass
        pass
    print('\n所有线程创建完毕。。')
    pass


index(False)  # 同步线程True，异步线程False（推荐）




