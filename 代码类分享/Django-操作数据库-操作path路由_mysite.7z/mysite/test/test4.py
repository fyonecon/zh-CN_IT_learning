import threading
import time

flag = 0


# 为线程定义一个函数
def print_time(create):
    for n in range(1, 10):
        print('线程内=' + str(n))

        pass

    time.sleep(3)
    # def printOne():
    #     while 1:
    #         print(111111111111)

    # th1 = threading.Thread(target=printOne)
    # th1.setDaemon(True)
    # th1.start()
    # while 1:
    #     if flag:
    #         print("正在停止这个程序！！！")
    #         break
    pass


if __name__ == '__main__':
    print('开启多线程。。')

    th_list = []  # 多线程标识数组

    for create in range(0, 4):  # 创建线程
        th = threading.Thread(print_time(create))
        th.start()
        th_list.append(th)
        print('已经创建线程=' + th.getName())
        print('----------------------')
        pass

    for del_th in range(0, len(th_list)):  # 关闭线程
        th_list[del_th].join()
        if th_list[del_th].isAlive():
            print('仍存活线程=' + str(th_list[del_th]))
            pass
        else:
            print('已关闭线程=' + str(th_list[del_th]))
            pass
        pass

    print('多线程完成。。')

while 1:
    pass
