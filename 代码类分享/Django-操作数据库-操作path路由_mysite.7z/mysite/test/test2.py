import _thread
import time


all_thread_num = 0


def page_class(cla, that_num):
    print("\n已启动线程=" + str(that_num))

    pass


if __name__ == '__main__':
    for cla in range(20000, 20010):  # 创建线程
        try:
            _thread.start_new_thread(page_class, (cla, (cla - 20000)))
            pass
        except:
            print("无法启动线程")
            pass
        pass
    # _thread.exit_thread()
    while 1:
        pass
    pass


# while 1:
#     pass
# else:
#     print('线程执行完毕。。。')
