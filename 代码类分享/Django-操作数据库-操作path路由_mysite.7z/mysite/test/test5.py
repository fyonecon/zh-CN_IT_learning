import threading, time, signal
import sys


def printA():
    while True:
        print('a')
        time.sleep(1)


def printB():
    while True:
        print('b')
        time.sleep(1)


def quit(signum, frame):
    print('You choose to stop me.')
    sys.exit()


if __name__ == '__main__':
    try:
        signal.signal(signal.SIGINT, quit)
        signal.signal(signal.SIGTERM, quit)

        a = threading.Thread(target=printA)
        b = threading.Thread(target=printB)
        a.setDaemon(True)
        a.start()
        b.setDaemon(True)
        b.start()

        while True:
            pass

    finally:
        print('over')
    pass
