#!/usr/bin/python3
# 线程异步

import threading
import time

exitFlag = 0


class myThread(threading.Thread):
    def __init__(self, thread_id, name, counter):
        threading.Thread.__init__(self)
        self.thread_id = thread_id
        self.name = name
        self.counter = counter
        pass

    def run(self):
        print("开始线程=" + self.name)
        run_def(self.name, self.counter, 5)
        print("退出线程=" + self.name)
        pass

    pass


def run_def(thread_name, delay, counter):
    while counter:
        if exitFlag:
            thread_name.exit()
            pass
        time.sleep(delay)
        # time.sleep(0)
        list(thread_name)
        counter -= 1
        pass
    pass


def list(thread_name):
    print("\n执行线程=" + thread_name)
    pass


threads = []  # 存储在线线程

# 创建线程
for this_t in range(1, 100000):
    t = myThread(this_t, "Thread-" + str(this_t), 3)
    t.start()
    threads.append(t)
    pass

# 终止线程
for t in threads:
    t.join()
    pass

print("程序完成！！")
