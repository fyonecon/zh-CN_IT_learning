"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path
from blog import views
# from spider import views
# python manage.py runserver 8080

urlpatterns = [
    path('admin/', admin.site.urls),

    # blog
    path('', views.index),  # 空目录
    path('test/', views.test),  # 不携带参数
    path('data1/', views.data1),  # GET携带参数
    path('data2/p1/<p1>/p2/<p2>/', views.data2),  # pathinfo携带参数
    path('json1/p1/<p1>/p2/<p2>/', views.json1),  # pathinfo携带参数，返回json

    # spider
    path('spider/', include('spider.urls')),

    # mysql
    path('mysql/', include('mysql.urls')),

    # blog
    path('blog/', include('blog.urls')),


]
