document.addEventListener('DOMContentLoaded', function() {
    var next = document.querySelector('.next');
    var replay = document.querySelector('.replay');
    var video = document.getElementById('video');
                          
    var progress = 1;
    controller.welcomeSlide();
                          
    next.addEventListener('click', function () {
        changeSlide(progress);
        progress++;
    });
                          
    replay.addEventListener('click', function () {
        video.load();
        video.play();
    });
                          
    function changeSlide(current) {
        var currentSlide = document.querySelector('.slide.-active');
        currentSlide.classList.remove('-active');
        var nextSlide = document.querySelector('[data-slide="'+(current + 1)+'"]');
        nextSlide.classList.add('-active');
                          
        // handle video
        if(current == 1) {
            controller.videoSlide();
            video.play();
        } else if (current == 2) {
            if(!video.paused) {
                video.pause();
            }
        }

        // remove buttons when third slide (with subscribe form)
        if(current + 1 == 3 ) {
            controller.subscribeSlide();
            next.style.display = 'none';
        }
    };

    // subscribe form
    var form = document.getElementById('form');
    var fields = form.querySelector('.fields');
    var thanks = form.querySelector('.thanks');
    var subscribe = document.getElementById('subscribe');
    var regEmail = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
	
    var emailField = document.querySelector('.email-subscribe');
    emailField.setAttribute('size', emailField.getAttribute('placeholder').length - 3);

	emailField.addEventListener('keyup', function() {
		emailField.classList.remove('error-email');
	})
		
    form.onsubmit = function (e) {
        e.preventDefault();
		if (regEmail.test(emailField.value)) {
			fields.style.display = 'none';
        	thanks.classList.add('-active');
        	controller.subscribed_(emailField.value);
        } else {
			emailField.classList.add('error-email');
		}
		emailField.focus();
    };
});
    

document.addEventListener("keydown", disableKeyboardEvents, true);

function disableKeyboardEvents(event) {
    event.preventDefault();
}

function enableKeyboardEvents() {
    document.removeEventListener("keydown", disableKeyboardEvents, true);
}

function startInitialTransitionAnimation() {
    document.body.classList.add('-animate');
}
